<link href="<?= $base ?>/assets/css/admin/ligas.css" rel="stylesheet">

<script type="text/javascript" src="<?= $base ?>/assets/js/admin/ligas.js"></script>