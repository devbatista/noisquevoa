<script type="text/javascript" src="<?= $base ?>/assets/js/script.js"></script>
</body>

</html>