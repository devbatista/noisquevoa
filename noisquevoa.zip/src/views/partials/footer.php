<footer>
    <hr>
    Todos os direitos reservados
</footer>
<script type="text/javascript" src="<?= $base ?>/assets/js/script.js"></script>
</body>

</html>