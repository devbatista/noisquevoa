<?php

namespace src\models;

use \core\Model;

class Liga extends Model
{
    public function __construct()
    {
        parent::__construct();
    }
}